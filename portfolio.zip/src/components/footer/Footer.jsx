
const Footer = () => {
  return (
    <div>
      <div className="text-center bg-white text-black">
      © Copyright Ashish Kumar
        
      </div>
      
    </div>
  )
}

export default Footer
